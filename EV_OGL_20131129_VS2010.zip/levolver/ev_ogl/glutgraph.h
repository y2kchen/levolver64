#ifndef __glutgraph_h__
#define __glutgraph_h__

extern void setOpenGL_key();
extern unsigned getOpenGL_key();
extern void TakeScreenshot(BOOL AskFileName);
#endif