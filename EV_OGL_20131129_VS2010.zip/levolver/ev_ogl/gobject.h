*  Purpose:  Needed Pixar defines.

#define QUAD 1
#define NQUAD 2
#define CQUAD 3
#define CNQUAD 4

