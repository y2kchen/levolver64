/* osfcn.h dummy */
